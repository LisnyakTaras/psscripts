﻿$emailSmtpServer = "ex.atbmarket.com"
$emailSmtpServerPort = "587"
#Для отправки письма нужен логин - пароль!!!
$emailSmtpUser = "Логин"
$emailSmtpPass = "пароль"
#по другому не получалось, если знаешь как можно упростить авторизацию, подскажи.
$emailMessage = New-Object System.Net.Mail.MailMessage

$emailMessage.From = "lisnyak.taras@atbmarket.com"
$emailMessage.To.Add( "lisnyak.taras@atbmarket.com" )
$emailMessage.Subject = "Testing e-mail"
#вставляю в переменную картинку
$Image = Get-Item C:\Users\lisnyakt\Pictures\Out_TestPort.PNG
#вставлем ссылку в переменную.
$attachment = "C:\Users\lisnyakt\Pictures\Out_TestPort.PNG"
$emailMessage.Attachments.Add( $attachment )
$emailMessage.IsBodyHtml = $true
$emailMessage.DeliveryNotificationOptions = $true
$emailMessage.Body = @"
<p>Забача №9 выполнена с помощью класса <strong>System.Net.Mail.MailMessage</strong>.</p>
<picture><img src=$Image ></picture>
"@
 
$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
 
$SMTPClient.Send( $emailMessage )