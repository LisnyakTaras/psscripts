﻿#Пример запуска : "Test-OpenPort STPSRV, BTTEST -Port 80, 443, 10050,139,8080,3389"

function Test-OpenPort {
 
param
 
(
[Parameter(Mandatory=$true)]
$Server,
$Port
)
 
$result=@()
     #цыкл обработки по  сервера
    foreach ($t in $Server)
    {
        #цыкл обработки по портам
       foreach ($p in $Port)
        {
        $a=Test-NetConnection -ComputerName $t -Port $p
         $result+=New-Object -TypeName PSObject -Property ([ordered]@{
        'Server'=$a.ComputerName;
        'RemoteAddress'=$a.RemoteAddress;
        'Port'=$a.RemotePort;
        'Status'=$a.tcpTestSucceeded})
        } 
    }
 
Write-Output $result 
}