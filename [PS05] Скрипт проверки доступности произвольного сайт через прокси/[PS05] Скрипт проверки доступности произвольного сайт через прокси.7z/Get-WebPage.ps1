﻿function Get-WebPage {
 
[cmdletbinding(
	DefaultParameterSetName = 'url',
	ConfirmImpact = 'low'
)]
    Param(
        [Parameter(
            Mandatory = $True,
            Position = 0,
            ParameterSetName = '',
            ValueFromPipeline = $True)]
            [string][ValidatePattern('^(http|https)\://*')]$Url,
        [Parameter(
            Position = 1,
            Mandatory = $False,
            ParameterSetName = 'defaultcred')]
            [switch]$UseDefaultCredentials,
        [Parameter(
            Mandatory = $False,
            ParameterSetName = '')]
            [string]$Proxy,
        [Parameter(
            Mandatory = $False,
            ParameterSetName = 'altcred')]
            [switch]$Credential,
        [Parameter(
            Mandatory = $False,
            ParameterSetName = '')]
            [switch]$ShowSize
        )
Begin {     
    $psBoundParameters.GetEnumerator() | % { 
        Write-Verbose 'Parameter: $_' 
        }
 
    #создаем объект
    Write-Verbose 'Creating web client object'
    $wc = New-Object Net.WebClient 
 
    #используем прокси
    If ($PSBoundParameters.ContainsKey('Proxy')) {
        #Create Proxy Address for Web Request
        Write-Verbose 'Creating proxy address and adding into Web Request'
        $wc.Proxy = New-Object -TypeName Net.WebProxy($proxy,$True)
        }       
 
    # аутентификация по-умолчанию
    If ($PSBoundParameters.ContainsKey('UseDefaultCredentials')) {
        #Set to True, otherwise remains False
        Write-Verbose 'Using Default Credentials'
        $webrequest.UseDefaultCredentials = $True
        }
    # данные аутентификации
    If ($PSBoundParameters.ContainsKey('Credentials')) {
                Write-Verbose 'Prompt for alternate credentials'
        $wc.Credential = (Get-Credential).GetNetworkCredential()
        }         
 
    }
Process {    
    Try {
        If ($ShowSize) {
            #получаем размер веб-страницы
            Write-Verbose 'Downloading web page and determining size'
            '{0:N0}' -f ($wr.DownloadString($url) | Out-String).length -as [INT]
            }
        Else {
            #получаем контент
            Write-Verbose 'Downloading web page and displaying source code' 
            $wc.DownloadString($url)       
            }
 
        }
    Catch {
        Write-Warning '$($Error[0])'
        }
    }   
}