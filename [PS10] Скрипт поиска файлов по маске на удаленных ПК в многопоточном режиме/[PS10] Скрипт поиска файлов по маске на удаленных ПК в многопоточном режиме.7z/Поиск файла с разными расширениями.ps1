﻿
  Param 
(
[parameter(Mandatory=$true)]$folder, #Путь где будем искать файлы
[parameter(Mandatory=$true)]$Name    #Имя файла
)



Start-Job -Name SearchTXT  -ScriptBlock { 
Param(
    $folder,
    $Name
)
    get-childItem $folder -Recurse -Filter *.txt| Where-Object { $_.Name -match "$Name" } | FT Name, directory }-ArgumentList $folder, $Name


Start-Job -Name SearchTXT  -ScriptBlock { 
Param(
    $folder,
    $Name
)
    get-childItem $folder -Recurse -Filter *.doc| Where-Object { $_.Name -match "$Name" } | FT Name, directory }-ArgumentList $folder, $Name

Start-Job -Name SearchTXT  -ScriptBlock { 
Param(
    $folder,
    $Name
)
    get-childItem $folder -Recurse -Filter *.docx| Where-Object { $_.Name -match "$Name" } | FT Name, directory }-ArgumentList $folder, $Name

Start-Job -Name SearchTXT  -ScriptBlock { 
Param(
    $folder,
    $Name
)
    get-childItem $folder -Recurse -Filter *.xls| Where-Object { $_.Name -match "$Name" } | FT Name, directory }-ArgumentList $folder, $Name

Start-Job -Name SearchTXT  -ScriptBlock { 
Param(
    $folder,
    $Name
)
    get-childItem $folder -Recurse -Filter *.xlsx| Where-Object { $_.Name -match "$Name" } | FT Name, directory }-ArgumentList $folder, $Name

While (Get-Job -State "Running") {
    cls
    Get-Job
    Start-Sleep 1 
}
cls
Get-Job
write-host "Jobs completed, getting output"

#get-childItem $folder -Recurse -Filter *.txt| Where-Object { $_.Name -match "$Name" } | FT Name, directory


    Receive-Job -Name SearchTXT | Out-File -FilePath D:\SearchResult.txt -Append    

Remove-Job *
notepad D:\SearchResult.txt