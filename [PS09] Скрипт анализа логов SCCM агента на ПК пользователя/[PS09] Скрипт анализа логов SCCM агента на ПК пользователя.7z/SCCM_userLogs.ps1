﻿#1)Нужно проверить файл C:\Windows\ccmsetup\Logs\ccmsetup.log на наличие кода 0 в конце лога(Если финальній код отличается от 0 то его нужно вывести в консоль)
$Logfile = "C:\Windows\ccmsetup\Logs\ccmsetup.log"
$txt="CcmSetup is exiting with return code 0"

$temp = Select-String -Path $Logfile -pattern $txt | Select-object -last 1

$containsWord = $temp | %{$_ -match $txt}

if ($containsWord -contains $true) {
    Write-Host "Log is fine!"
    Write-Host $containsWord
} else {
    Write-Host $temp
}


#2)Нужно Вывечсти последнюю запись в файле C:\Windows\CCM\Logs\ClientLocation.log

Select-String -Path C:\Windows\CCM\Logs\ClientLocation.log -pattern log | Select-object -last 1

#3)Нужно проверить наличие и статус службы Узел агента SMS (Онв должна быть в статусе Запущена, елси нет - вывести в консоль что служба не запущена)

$service = Get-Service -name CcmExec

if($service.Status -ne "Running"){
Write-Host "Служба не запущена!"
   }
